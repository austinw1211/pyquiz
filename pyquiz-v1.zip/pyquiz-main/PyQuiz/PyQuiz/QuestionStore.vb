﻿Module QuestionStore
    Public Questions As New List(Of Question)

    Public Sub SeedData()
        If Questions.Count > 0 Then Return

        Questions.Add(New Question With {
            .Text = "What is Dog?",
            .Choices = New List(Of String) From {"Animal", "Car", "Tree", "Fish"},
            .CorrectIndex = 0
        })

        Questions.Add(New Question With {
            .Text = "Best SWOSU Building",
            .Choices = New List(Of String) From {"Stafford", "Education", "Student Union", "Old Science"},
            .CorrectIndex = 2
        })
    End Sub
End Module
