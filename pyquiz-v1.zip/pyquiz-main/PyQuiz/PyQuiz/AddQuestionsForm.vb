﻿Public Class AddQuestionsForm

    Private Sub AddQuestionsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbCorrect.SelectedIndex = 0
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim q As New Question With {
            .Text = txtQuestion.Text,
            .Choices = New List(Of String) From {txt1.Text, txt2.Text, txt3.Text, txt4.Text},
            .CorrectIndex = cmbCorrect.SelectedIndex
        }

        QuestionStore.Questions.Add(q)
        MessageBox.Show("Question Added!")
        Me.Close()
    End Sub
End Class
