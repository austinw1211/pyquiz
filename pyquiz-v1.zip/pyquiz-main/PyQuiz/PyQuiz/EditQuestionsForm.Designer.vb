﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditQuestionsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lstQuestions = New ListBox()
        txtQuestion = New TextBox()
        txt4 = New TextBox()
        txt3 = New TextBox()
        txt2 = New TextBox()
        txt1 = New TextBox()
        cmbCorrect = New ComboBox()
        btnSave = New Button()
        SuspendLayout()
        ' 
        ' lstQuestions
        ' 
        lstQuestions.FormattingEnabled = True
        lstQuestions.Location = New Point(32, 38)
        lstQuestions.Name = "lstQuestions"
        lstQuestions.Size = New Size(226, 379)
        lstQuestions.TabIndex = 0
        ' 
        ' txtQuestion
        ' 
        txtQuestion.Location = New Point(323, 130)
        txtQuestion.Name = "txtQuestion"
        txtQuestion.Size = New Size(257, 23)
        txtQuestion.TabIndex = 1
        ' 
        ' txt4
        ' 
        txt4.Location = New Point(323, 296)
        txt4.Name = "txt4"
        txt4.Size = New Size(257, 23)
        txt4.TabIndex = 2
        ' 
        ' txt3
        ' 
        txt3.Location = New Point(323, 251)
        txt3.Name = "txt3"
        txt3.Size = New Size(257, 23)
        txt3.TabIndex = 3
        ' 
        ' txt2
        ' 
        txt2.Location = New Point(323, 210)
        txt2.Name = "txt2"
        txt2.Size = New Size(257, 23)
        txt2.TabIndex = 4
        ' 
        ' txt1
        ' 
        txt1.Location = New Point(323, 169)
        txt1.Name = "txt1"
        txt1.Size = New Size(257, 23)
        txt1.TabIndex = 5
        ' 
        ' cmbCorrect
        ' 
        cmbCorrect.FormattingEnabled = True
        cmbCorrect.Location = New Point(323, 342)
        cmbCorrect.Name = "cmbCorrect"
        cmbCorrect.Size = New Size(257, 23)
        cmbCorrect.TabIndex = 6
        ' 
        ' btnSave
        ' 
        btnSave.Location = New Point(356, 388)
        btnSave.Name = "btnSave"
        btnSave.Size = New Size(75, 23)
        btnSave.TabIndex = 7
        btnSave.Text = "Save"
        btnSave.UseVisualStyleBackColor = True
        ' 
        ' EditQuestionsForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btnSave)
        Controls.Add(cmbCorrect)
        Controls.Add(txt1)
        Controls.Add(txt2)
        Controls.Add(txt3)
        Controls.Add(txt4)
        Controls.Add(txtQuestion)
        Controls.Add(lstQuestions)
        Name = "EditQuestionsForm"
        Text = "EditQuestionsForm"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lstQuestions As ListBox
    Friend WithEvents txtQuestion As TextBox
    Friend WithEvents txt4 As TextBox
    Friend WithEvents txt3 As TextBox
    Friend WithEvents txt2 As TextBox
    Friend WithEvents txt1 As TextBox
    Friend WithEvents cmbCorrect As ComboBox
    Friend WithEvents btnSave As Button
End Class
