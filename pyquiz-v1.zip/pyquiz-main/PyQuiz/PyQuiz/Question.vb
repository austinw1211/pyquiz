﻿Public Class Question
    Public Property Text As String
    Public Property Choices As List(Of String)
    Public Property CorrectIndex As Integer
End Class
