﻿Public Class QuizForm
    Private currentIndex As Integer = 0

    Private Sub QuizForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadQuestion()
    End Sub

    Private Sub LoadQuestion()
        If currentIndex >= QuestionStore.Questions.Count Then
            MessageBox.Show("Quiz Complete!")
            Me.Close()
            Return
        End If

        Dim q = QuestionStore.Questions(currentIndex)

        lblQuestion.Text = q.Text
        r1.Text = q.Choices(0)
        r2.Text = q.Choices(1)
        r3.Text = q.Choices(2)
        r4.Text = q.Choices(3)

        r1.Checked = False
        r2.Checked = False
        r3.Checked = False
        r4.Checked = False
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim selected As Integer = -1

        If r1.Checked Then selected = 0
        If r2.Checked Then selected = 1
        If r3.Checked Then selected = 2
        If r4.Checked Then selected = 3

        Dim correct = QuestionStore.Questions(currentIndex).CorrectIndex

        If selected = correct Then
            MessageBox.Show("Correct!")
        Else
            MessageBox.Show("Wrong!")
        End If

        currentIndex += 1
        LoadQuestion()
    End Sub
End Class
