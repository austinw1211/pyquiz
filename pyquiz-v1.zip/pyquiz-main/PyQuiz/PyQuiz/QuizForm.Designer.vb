﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class QuizForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblQuestion = New Label()
        r1 = New RadioButton()
        r2 = New RadioButton()
        r3 = New RadioButton()
        r4 = New RadioButton()
        btnSubmit = New Button()
        SuspendLayout()
        ' 
        ' lblQuestion
        ' 
        lblQuestion.AutoSize = True
        lblQuestion.Location = New Point(95, 103)
        lblQuestion.Name = "lblQuestion"
        lblQuestion.Size = New Size(41, 15)
        lblQuestion.TabIndex = 0
        lblQuestion.Text = "Label1"
        ' 
        ' r1
        ' 
        r1.AutoSize = True
        r1.Location = New Point(95, 154)
        r1.Name = "r1"
        r1.Size = New Size(97, 19)
        r1.TabIndex = 1
        r1.TabStop = True
        r1.Text = "RadioButton1"
        r1.UseVisualStyleBackColor = True
        ' 
        ' r2
        ' 
        r2.AutoSize = True
        r2.Location = New Point(95, 213)
        r2.Name = "r2"
        r2.Size = New Size(97, 19)
        r2.TabIndex = 2
        r2.TabStop = True
        r2.Text = "RadioButton2"
        r2.UseVisualStyleBackColor = True
        ' 
        ' r3
        ' 
        r3.AutoSize = True
        r3.Location = New Point(95, 271)
        r3.Name = "r3"
        r3.Size = New Size(97, 19)
        r3.TabIndex = 3
        r3.TabStop = True
        r3.Text = "RadioButton3"
        r3.UseVisualStyleBackColor = True
        ' 
        ' r4
        ' 
        r4.AutoSize = True
        r4.Location = New Point(95, 326)
        r4.Name = "r4"
        r4.Size = New Size(97, 19)
        r4.TabIndex = 4
        r4.TabStop = True
        r4.Text = "RadioButton4"
        r4.UseVisualStyleBackColor = True
        ' 
        ' btnSubmit
        ' 
        btnSubmit.Location = New Point(369, 392)
        btnSubmit.Name = "btnSubmit"
        btnSubmit.Size = New Size(75, 23)
        btnSubmit.TabIndex = 5
        btnSubmit.Text = "Submit"
        btnSubmit.UseVisualStyleBackColor = True
        ' 
        ' QuizForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btnSubmit)
        Controls.Add(r4)
        Controls.Add(r3)
        Controls.Add(r2)
        Controls.Add(r1)
        Controls.Add(lblQuestion)
        Name = "QuizForm"
        Text = "QuizForm"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblQuestion As Label
    Friend WithEvents r1 As RadioButton
    Friend WithEvents r2 As RadioButton
    Friend WithEvents r3 As RadioButton
    Friend WithEvents r4 As RadioButton
    Friend WithEvents btnSubmit As Button
End Class
