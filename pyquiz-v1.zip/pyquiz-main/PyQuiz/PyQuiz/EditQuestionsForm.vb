﻿Public Class EditQuestionsForm
    Private selectedIndex As Integer = -1

    Private Sub EditQuestionsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RefreshList()
        cmbCorrect.SelectedIndex = 0
    End Sub

    Private Sub RefreshList()
        lstQuestions.Items.Clear()
        For Each q In QuestionStore.Questions
            lstQuestions.Items.Add(q.Text)
        Next
    End Sub

    Private Sub lstQuestions_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstQuestions.SelectedIndexChanged
        selectedIndex = lstQuestions.SelectedIndex
        If selectedIndex < 0 Then Return

        Dim q = QuestionStore.Questions(selectedIndex)
        txtQuestion.Text = q.Text
        txt1.Text = q.Choices(0)
        txt2.Text = q.Choices(1)
        txt3.Text = q.Choices(2)
        txt4.Text = q.Choices(3)
        cmbCorrect.SelectedIndex = q.CorrectIndex
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If selectedIndex < 0 Then Return

        Dim q = QuestionStore.Questions(selectedIndex)
        q.Text = txtQuestion.Text
        q.Choices = New List(Of String) From {txt1.Text, txt2.Text, txt3.Text, txt4.Text}
        q.CorrectIndex = cmbCorrect.SelectedIndex

        RefreshList()
        MessageBox.Show("Saved!")
    End Sub
End Class
